#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rclpy
from geometry_msgs.msg import Twist
from rclpy.node import Node 


class PublisherNode(Node):
          def __init__(self, name):
                    super().__init__(name)                                    # ROS2节点父类初始化
                    self.pub = self.create_publisher(Twist,"/turtle1/cmd_vel",  10)   # 创建发布者对象（消息类型、话题名、队列长度）
                    self.i=0
                    self.timer = self.create_timer(0.01, self.timer_callback)  # 创建一个定时器（单位为秒的周期，定时执行的回调函数）
          
          def timer_callback(self):
                    msg1 = Twist()                                            # 创建一个String类型的消息对象
                    msg1.linear.x = 1.0
                    msg2=Twist()
                    msg2.linear.x = 1.0
                    msg2.angular.z = 0.5
                    
                    
                    if self.i<200:
                              self.pub.publish(msg1)
                              
                    else:
                              self.pub.publish(msg2)
                    self.i += 1

def main(args=None):
          rclpy.init(args=args)                       # ROS2 Python接口初始化
          node = PublisherNode("control_circle_p")  # 创建ROS2节点对象并进行初始化
          rclpy.spin(node)                            # 循环等待ROS2退出
          node.destroy_node()                         # 销毁节点对象
          rclpy.shutdown()                            # 关闭ROS2 Python接口
