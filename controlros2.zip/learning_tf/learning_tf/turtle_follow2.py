#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
xing kaiyue
"""
import math
import rclpy                                              # ROS2 Python接口库
from rclpy.node import Node                               # ROS2 节点类
import tf_transformations                                 # TF坐标变换库
from tf2_ros import TransformException                    # TF左边变换的异常类
from tf2_ros.buffer import Buffer                         # 存储坐标变换信息的缓冲类
from tf2_ros.transform_listener import TransformListener  # 监听坐标变换的监听器类
from geometry_msgs.msg import Twist                       # ROS2 速度控制消息
from turtlesim.srv import Spawn                           # 海龟生成的服务接口
from scipy.integrate import odeint
from turtlesim.msg import Pose  
import numpy as np

class Try(Node):

    def __init__(self, name):
        super().__init__(name)
        # self.declare_parameter('source_frame', 'turtle1')           # 创建一个源坐标系名的参数
        # self.source_frame = self.get_parameter(                     # 优先使用外部设置的参数值，否则用默认值
        #     'source_frame').get_parameter_value().string_value

        self.tf_buffer = Buffer()                                   # 创建保存坐标变换信息的缓冲区
        #self.tf_listener = TransformListener(self.tf_buffer, self)  # 创建坐标变换的监听器

        self.spawner = self.create_client(Spawn, 'spawn')           # 创建一个请求产生海龟的客户端
        self.turtle_spawning_service_ready = False                  # 是否已经请求海龟生成服务的标志位
        self.turtle_spawned = False                                 # 海龟是否产生成功的标志位                                      # ROS2节点父类初始化
        
        #self.publisher = self.create_publisher(Twist,'/turtle1/cmd_vel', 10)
        #self.sub = self.create_subscription(Pose,"/turtle1/pose",self.huidiao, 10)
        self.publisher = self.create_publisher(Twist, 'turtle2/cmd_vel', 1) # 创建跟随运动海龟的速度话题
        self.timer = self.create_timer(0.01, self.on_timer) 
    
    def huidiao(self,pose):
        global x_f
        self.x_f=pose.x
        x_f = pose.x
        self.y_f=pose.y
        self.pusai_f=pose.theta
        self.v_f=pose.linear_velocity
        self.w_f=pose.angular_velocity
        self.get_logger().info('Publishing: x_f"%f "' % self.x_f)
        self.get_logger().info('Publishing: y_f"%f "' % self.y_f)
    def huidiao2(self,pose):
        global v_n
        self.x_n=pose.x
        self.y_n=pose.y
        self.pusai_n=pose.theta
        self.v_n=pose.linear_velocity
        self.w_n=pose.angular_velocity
        self.cs_n=[self.x_n,self.y_n,self.pusai_n,self.v_n,self.w_n,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]
        self.t1=np.arange(0,4,0.01)
        sol1= odeint(self.lorenz,self.cs_n,self.t1)
        self.get_logger().info('Publishing: x_n"%f "' % self.x_n)
        self.get_logger().info('Publishing: y_n"%f "' % self.y_n)
        msg = Twist()         # 创建速度控制消息
        msg.linear.x=sol1[1,3]
        msg.angular.z= sol1[1,4]
        self.publisher.publish(msg)
        #self.get_logger().info('Publishing: sol"%f"' % sol1[1,3])
        #self.trry(x_f)
    # def trry(self,x_f):
    #     self.get_logger().info('Publishing: z"%f"' % x_f)
        
    def lorenz (self,cs_n,t1):

        des_d = 1.1 
        D1=np.sqrt(np.power(self.x_n-self.x_f,2)+np.power(self.y_n-self.y_f,2))
        x_piao = np.cos(self.pusai_n)*(self.x_f-self.x_n)+np.sin(self.pusai_n)*(self.y_f-self.y_n)
        y_piao = -np.sin(self.pusai_n) * (self.x_f - self.x_n) + np.cos(self.pusai_n) * (self.y_f - self.y_n)
        theta = math.atan2(y_piao, x_piao)
        fai = theta+self.pusai_n-self.pusai_f
        k_d1=2  #k_d1i
        k_theta1=3 #k_theta1i
        k_1=100#k_1i
        k_2=100 #k_2i
        k_d=0.01 #k_di
        k_theta=0.01 #k_thetai
        gama1=15  #sigmai1
        gama2=15  #sigmai2
        #prescribed performance function
        beta_d=(1-0.08)*np.exp(-0.15*t1)+0.08
        beta_theta=(1-0.08)*np.exp(-0.15*t1)+0.08
        dbeta_d=-0.138*np.exp(-0.15*t1);
        dbeta_theta=-0.138*np.exp(-0.15*t1)
        #distance error & angle error
        e_d=D1-des_d ; e_theta=theta
        # av virtual control
        av = (k_d1 * e_d + self.v_f*np.cos(fai) + k_d*np.power(beta_d,2)/(np.pi*e_d)*np.sin(0.5*np.pi*np.power(e_d,2)/np.power(beta_d,2))*
            np.cos(0.5*np.pi*np.power(e_d,2)/np.power(beta_d,2)))/np.cos(theta)
        aw = k_theta1*e_theta + k_theta*np.power(beta_theta,2)/(np.pi*e_theta)*np.sin(0.5*np.pi*np.power(e_theta,2)/np.power(beta_theta,2))*np.cos(0.5 * np.pi * np.power(e_theta, 2)/np.power(beta_theta, 2))
        + self.v_n*np.sin(theta)/D1 - self.v_f*np.sin(fai)/D1
        #误差变换
        z21 = self.v_n - av ; z22 = self.w_n - aw
        #自适应控制
        Theta1v = np.array([cs_n[5],cs_n[6],cs_n[7],cs_n[8]]).T ; Theta1w=np.array([cs_n[9],cs_n[10],cs_n[11],cs_n[12]]).T
        de_d = -self.v_n*np.cos(theta)+self.v_f*np.cos(fai)
        de_theta = -self.w_n + self.v_n*np.sin(theta)/D1 - self.v_f*np.sin(fai)/D1
        t11 = k_d*(2*beta_d*dbeta_d*e_d-np.power(beta_d,2)*de_d)/(np.pi*np.power(e_d,2))*np.sin(0.5*np.pi*np.power(e_d,2)/np.power(beta_d,2))*np.cos(0.5*np.pi*np.power(e_d,2)/np.power(beta_d,2))
        t12 = k_d*(de_d*np.power(beta_d,2)-beta_d*dbeta_d*e_d)/np.power(beta_d,2)*(np.power(np.cos(0.5*np.pi*np.power(e_d,2)/np.power(beta_d,2)),2)-np.power(np.sin(0.5*np.pi*np.power(e_d,2)/np.power(beta_d,2)),2))
        t21 = k_theta*(2*beta_theta*dbeta_theta*e_theta-np.power(beta_theta,2)*de_theta)/(np.pi*np.power(e_theta,2))*np.sin(0.5*np.pi*np.power(e_theta,2)/np.power(beta_theta,2))*np.cos(0.5*np.pi*np.power(e_theta,2)/np.power(beta_theta,2))
        t22 = k_theta*(de_theta*np.power(beta_theta,2)-beta_theta*dbeta_theta*e_theta)/np.power(beta_theta,2)*(np.power(np.cos(0.5*np.pi*np.power(e_theta,2)/np.power(beta_theta,2)),2)-np.power(np.sin(0.5*np.pi*np.power(e_theta,2)/np.power(beta_theta,2)),2))
        d_av = av*np.tan(theta)+(t11+t12)/np.cos(theta)
        d_aw = k_theta*de_theta+t21+t22
        G1 = np.array([np.power(self.w_n,2),-self.v_n,-self.w_n,-d_av])
        G2 = np.array([-self.v_n*self.w_n,-self.v_n,-self.w_n,-d_aw])
        #control law
        tao_v = -k_1*z21 - np.dot(G1,Theta1v) + (1+np.power(np.tan(0.5*np.pi*np.power(e_d,2)/np.power(beta_d,2)),2))*e_d*np.cos(theta)
        tao_w = -k_2*z22 - np.dot(G2,Theta1w) + (1+np.power(np.tan(0.5*np.pi*np.power(e_theta,2)/np.power(beta_theta,2)),2))*e_theta
        #weifen

        dx = self.v_n*np.cos(self.pusai_n)
        dy = self.v_n*np.sin(self.pusai_n)
        dpusai = self.w_n
        dv = np.power(self.w_n, 2)*81/292-self.v_n*1000/73+tao_v*15/73
        dw = -self.v_n*self.w_n*1800/3941-self.w_n*50000/3941+tao_w*1000/3941

        dTheta1v = gama1*G1*z21
        dTheta1w = gama2*G2*z22
        self.d_z = [dx,dy,dpusai,dv,dw,dTheta1v[0],dTheta1v[1],dTheta1v[2],dTheta1v[3],dTheta1w[0],dTheta1w[1],dTheta1w[2],dTheta1w[3]]
        return self.d_z
        
    def on_timer(self):
        # self.get_logger().info('Publishing: x"%f"' % pose.x)
        # self.get_logger().info('Publishing: z"%f"' % pose.y)
        if self.turtle_spawning_service_ready:                     # 如果已经请求海龟生成服务
            if self.turtle_spawned:                                # 如果跟随海龟已经生成
                #self.cs_n=[]
                self.sub = self.create_subscription(Pose,"/turtle1/pose",self.huidiao, 1)
                self.sub2 = self.create_subscription(Pose,"/turtle2/pose",self.huidiao2, 1)
                
                
                #self.t1=np.arange(0,4,0.01)
                #self.get_logger().info('Publishing: z"%f"' % v_n)
                #self.sol1= odeint(self.lorenz,cs_n,self.t1)
                #msg = Twist()         # 创建速度控制消息
                #msg.linear.x=self.sol1[1,3]
                #msg.angular.z= self.sol1[1,4] 
                #self.publisher.publish(msg)

            else:                                                  # 如果跟随海龟没有生成
                if self.result.done():                             # 查看海龟是否生成
                    self.get_logger().info(
                        f'Successfully spawned {self.result.result().name}')
                    self.turtle_spawned = True                     
                else:                                              # 依然没有生成跟随海龟
                    self.get_logger().info('Spawn is not finished')
        else:                                                      # 如果没有请求海龟生成服务
            if self.spawner.service_is_ready():                    # 如果海龟生成服务器已经准备就绪
                request = Spawn.Request()                          # 创建一个请求的数据
                request.name = 'turtle2'                           # 设置请求数据的内容，包括海龟名、xy位置、姿态
                request.x = float(4)
                request.y = float(2)
                request.theta = float(0)

                self.result = self.spawner.call_async(request)     # 发送服务请求
                self.turtle_spawning_service_ready = True          # 设置标志位，表示已经发送请求
            else:
                self.get_logger().info('Service is not ready')     # 海龟生成服务器还没准备就绪的提示
        
                    

def main(args=None):
    rclpy.init(args=args)                       # ROS2 Python接口初始化
    node = Try("turtle_follow2")  # 创建ROS2节点对象并进行初始化
    rclpy.spin(node)                            # 循环等待ROS2退出
    node.destroy_node()                         # 销毁节点对象
    rclpy.shutdown()                            # 关闭ROS2 Python接口