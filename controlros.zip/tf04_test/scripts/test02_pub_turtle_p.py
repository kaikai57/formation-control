#! /usr/bin/env python
from ast import If
import turtle
import rospy
from turtlesim.msg import Pose
import tf2_ros
from geometry_msgs.msg import TransformStamped
import tf_conversions
import sys  #Analytical parameters


'''
prepare
    topic: /turtle/pose
    type:/turtlesim/Pose

propess
    1.import
    2.initialize the ROS node
    3.create  a subscription object
    4.use the  callback function to processes the subscribed information
    5.spin()
'''
#Receiving tortoise Name
turtle_name = ""
def doPose(pose):
    #1.Creates an object that publishes coordinate system relativities
    pub = tf2_ros.TransformBroadcaster()
    #2. Transform the pose into a coordinate relative message
    ts = TransformStamped()
    #header
    ts.header.stamp=rospy.Time.now()
    ts.header.frame_id="world"
    #Offset of the child coordinate system from the parent coordinate system
    ts.child_frame_id=turtle_name
    #Relative relation
    ts.transform.translation.x=pose.x
    ts.transform.translation.y=pose.y
    ts.transform.translation.z=0.0
    #4.1converting Euler angles to quaternions
    qtn=tf_conversions.transformations.quaternion_from_euler(0,0,pose.theta)
    ts.transform.rotation.x=qtn[0]
    ts.transform.rotation.y=qtn[1]
    ts.transform.rotation.z=qtn[2]
    ts.transform.rotation.w=qtn[3]
    #3.publish
    pub.sendTransform(ts)
   
if __name__ == "__main__":
    # 2.initialize the ROS node
    rospy.init_node("dynamic_tf_pub_p")
    if len(sys.argv) != 4:
        rospy.loginfo("flause")
        sys.exit(1)
    else:
        turtle_name = sys.argv[1]
    # 3.create  a subscription object
    sub = rospy.Subscriber("/"+turtle_name+"/pose",Pose,doPose,queue_size=100)  #doPose:callback queue_size:queue length
    # 4.use the  callback function to processes the subscribed information
    # 5.spin()
    rospy.spin()
    pass
