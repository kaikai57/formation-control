#! /usr/bin/env python
#1.import
import rospy
from turtlesim.srv import Spawn, SpawnRequest, SpawnResponse

if __name__ == "__main__":
    # 2.initialize the ros node
    rospy.init_node("turtle_spawn_p")
    # 3.Create a service client
    client = rospy.ServiceProxy("/spawn",Spawn)
    # 4.Waiting for the service launch
    client.wait_for_service()
    # 5.Create request data
    req = SpawnRequest()
    req.x = 4.0
    req.y = 2.0
    req.theta = 3.14
    req.name = "turtle2"
    # 6.Send the request and process the response
    client.wait_for_service()
    try:
        response = client.call(req)
        rospy.loginfo("create successful,the name is:%s",response.name)
    except Exception as e:
        rospy.loginfo("Service invocation failure....")

