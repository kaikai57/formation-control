#! /usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from turtlesim.srv import Spawn, SpawnRequest, SpawnResponse
if __name__ == "__main__":

    rospy.init_node("my_control_p")

    pub = rospy.Publisher("/turtle1/cmd_vel",Twist,queue_size=1000)
    
    rate = rospy.Rate(10)
    msg1=  Twist()
    msg1.linear.x=1

    msg2 = Twist()
    msg2.linear.x = 1.0
    msg2.linear.y = 0.0
    msg2.linear.z = 0.0
    msg2.angular.x = 0.0
    msg2.angular.y = 0.0
    msg2.angular.z = 0.5

    count=0
    while count<30:
        pub.publish(msg1)
        rate.sleep()
        count+=1
        
    while not rospy.is_shutdown():
        pub.publish(msg2)
        rate.sleep()
