#! /usr/bin/env python
from ast import Expression
import rospy
import tf2_ros
from tf2_geometry_msgs import tf2_geometry_msgs
from geometry_msgs.msg import TransformStamped,Twist
from tf2_geometry_msgs import PointStamped
import math
if  __name__ =="__main__":
    # Initializ a node
    rospy.init_node("static_sub_p3")
    # Creating a subscription object
        #3.1Creating a cache object
    buffer3 = tf2_ros.Buffer()
        #3.2Creating a subscription object
    listener=tf2_ros.TransformListener(buffer3)
    rate = rospy.Rate(10)
    #Create a speed message publication object
    pub3=rospy.Publisher("/turtle3/cmd_vel",Twist,queue_size=100)
   
    # Transform logic implementation, call TF encapsulation algorithm
    
    while not rospy.is_shutdown():
        rate.sleep()
        try:
            #The coordinate relation of son1 with respect to son2
            ts3 = buffer3.lookup_transform("turtle3","turtle2",rospy.Time(0))
            rospy.loginfo("parent coordinate:%s , child corrdinate :%s,the offset(%.2f,%.2f,%.2f)",
                                        ts3.header.frame_id,
                                        ts3.child_frame_id,
                                        ts3.transform.translation.x,
                                        ts3.transform.translation.y,
                                        ts3.transform.translation.z
                                        )
            # Organize a Twist message
            twist3=Twist()
            #Linear velocity = coefficient * sqrt(x*2 + y*2)
            twist3.linear.x=0.5*math.sqrt(math.pow(ts3.transform.translation.x,2)+math.pow(ts3.transform.translation.y,2))           
            #angular velocity = coefficient*athan2(y,x)
            twist3.angular.z = 4*math.atan2(ts3.transform.translation.y,ts3.transform.translation.x)

            # publish
            pub3.publish(twist3)
        except Exception as e:
            rospy.logwarn("wrong:%s",e)
    
        rate.sleep()
    pass