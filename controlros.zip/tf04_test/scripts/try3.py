#! /usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from turtlesim.srv import Spawn, SpawnRequest, SpawnResponse

if __name__ == "__main__":

    rospy.init_node("my_control_pp")

    pub = rospy.Publisher("/turtle1/cmd_vel",Twist,queue_size=1000)
    a=[0,0.51325446,0.893058601,1.178170603,1.399351119,1.579255117,1.733575914,1.872751271,2.003545616,2.130072747,2.25525636,
2.380520124,2.50661223,2.633868055,2.761571721,2.888090595,3.010133048,3.122642155,3.218904777,3.288987292]
    b=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    
    msg2 = Twist()
    msg2.linear.x = 1.0
    msg2.linear.y = 0.0
    msg2.linear.z = 0.0
    msg2.angular.x = 0.0
    msg2.angular.y = 0.0
    msg2.angular.z = 0.5
    
    count=0
    rate = rospy.Rate(10)
    while count<20:
        ms=Twist()
        ms.linear.x=a[count]
        ms.angular.z=b[count]
        pub.publish(ms)
        rate.sleep()
        count+=1

    while not rospy.is_shutdown():
        pub.publish(msg2)
        rate.sleep()





